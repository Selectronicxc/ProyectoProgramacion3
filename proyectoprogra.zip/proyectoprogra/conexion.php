<?php
$cadena =
"
host='localhost' 
port='5432' 
dbname='basededatosprogra' 
user='alisson' 
password='luna'";

$conectar=pg_connect($cadena) 
or die ("fallo de conexion".pg_last_error());
?>
