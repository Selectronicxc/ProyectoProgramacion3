<?php

include "core/librerias/basededatos.postgresql.php";
if (isset($_REQUEST['guardar'])){



    $id_claificacion = $_REQUEST['id_clasificacion'];
    $clasificacion  =  $_REQUEST['clasifcacion'];

    $sql = "
    insert into activo VALUES (
    "."'"."$id_clasificacion"."'".","."clasificacion)

    ";

    $res = ejecutar($sql);

    if ($res == TRUE){
        echo "guardado con exito";
    }else{
        echo "No se pudo guardar";
    }

}


?>



<form class="form-horizontal" method="post" action="./?cont=nuevo_activo">
    <fieldset>

        <!-- Form Name -->
        <legend>clasificacion</legend>

        <input type="hidden" name="guardar" value="1">

         <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="id_clasificacion">id_clasificacion</label>
            <div class="col-md-4">
                <input id="id_clasificacion" name="id_clasificacion" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

        <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="clasificacion">clasificacion</label>
            <div class="col-md-4">
                <input id="clasificacion" name="clasificacion" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

       

        <!-- Button -->
        <div class="form-group">
            <label class="col-md-4 control-label" for="Guardar"></label>
            <div class="col-md-4">
                <button id="Guardar" name="Guardar" class="btn btn-primary">Guardar</button>
            </div>
        </div>

    </fieldset>
</form>
