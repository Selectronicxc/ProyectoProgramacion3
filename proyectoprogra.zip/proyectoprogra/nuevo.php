


<?php
$cadena =
"
host='localhost' 
port='5432' 
dbname='basededatosprogra' 
user='alisson' 
password='luna'";

$conectar=pg_connect($cadena) 
or die ("fallo de conexion".pg_last_error());
?>
<?php
if (isset($_REQUEST['guardar'])){



    $id_medicina = $_REQUEST['id_medicina'];
    $codigo  =  $_REQUEST['codigo'];
    $correlativo =  $_REQUEST['correlativo'];
    $medicamento =  $_REQUEST['medicamento'];
    $concentracion =  $_REQUEST['concentracion'];
    $forma_farmaceutica =  $_REQUEST['forma_farmaceutica'];
    $via =  $_REQUEST['via'];
	$indicaciones_terapeuticas =  $_REQUEST['indicaciones terapeuticas'];
	$cod_clasificacion =  $_REQUEST['cod_clasificacion'];
	$contraindicaciones =  $_REQUEST['contraindicaciones+
	'];

    $sql = "
    insert into activo VALUES (
    "."'"."$id_medicina"."'".","."codigo,"."'"."$correlativo"."'".","."'"."$medicamento"."'".",$concentracion,"."'"."$forma_farmaceutica"."'".",$via,"."'"."$indicaciones_terapeuticas,"."'"."cod_clasificacion,"."'"."contraindicaciones)

    ";

    $res = ejecutar($sql);

    if ($res == TRUE){
        echo "guardado con exito";
    }else{
        echo "No se pudo guardar";
    }

}


?>



<form class="form-horizontal" method="post" action="./?cont=nuevo_activo">
    <fieldset>

        <!-- Form Name -->
        <legend>medicina</legend>

        <input type="hidden" name="guardar" value="1">

         <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="id_medicina">id_medicina</label>
            <div class="col-md-4">
                <input id="id_medicina" name="id_medicina" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

        <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="codigo">Codigo</label>
            <div class="col-md-4">
                <input id="codigo" name="codigo" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

       
        <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="correlativo">correlativo</label>
            <div class="col-md-4">
                <input id="correlativo" name="correlativo" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

       
        <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="valort">medicamento</label>
            <div class="col-md-4">
                <input id="medicamento" name="medicamento" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

  <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="concentracion">concentracion</label>
            <div class="col-md-4">
                <input id="concentracion" name="concentracion" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

        <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="forma_farmaceutica">forma_farmaceutica</label>
            <div class="col-md-4">
                <input id="forma_farmaceutica" name="forma_farmaceutica" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

  <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="via">via</label>
            <div class="col-md-4">
                <input id="via" name="via" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>
      
      <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="indicaciones_terapeuticas">indicaciones_terapeuticas</label>
            <div class="col-md-4">
                <input id="indicaciones_terapeuticas" name="indicaciones_terapeuticas" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>
        
        <!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="cod_clasificacion">cod_clasificacion</label>
            <div class="col-md-4">
                <input id="cod_clasificacion" name="cod_clasificacion" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

	<!-- Text input-->
        <div class="form-group">
            <label class="col-md-4 control-label" for="contraindicaciones">contraindicaciones</label>
            <div class="col-md-4">
                <input id="contraindicaciones" name="contraindicaciones" type="text" placeholder="" class="form-control input-md" required="">

            </div>
        </div>

        <!-- Button -->
        <div class="form-group">
            <label class="col-md-4 control-label" for="Guardar"></label>
            <div class="col-md-4">
                <button id="Guardar" name="Guardar" class="btn btn-primary">Guardar</button>
            </div>
        </div>

    </fieldset>
</form>
