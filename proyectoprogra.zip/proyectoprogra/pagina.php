<?php
	include_once('conexion.php');
	
	if (!isset($_SESSION)) 
	{
	  session_start();
	}
	
	$=$_POST['nombre'];
	$password=$_POST['clave'];

		while($fila = pg_fetch_array($resultado))
		$_SESSION["id_medicina"]=$fila['id_medicina'];
		$_SESSION["codigo"]=$fila['codigo'];
		$_SESSION["correlativo"]=$fila['correlativo'];
		$_SESSION["medicamento"]=$fila['medicamento'];
		$_SESSION["consentracion"]=$fila['concentracion'];
		$_SESSION["forma_farmaceutica"]=$fila['forma_farmaceutica'];
		$_SESSION["via"]=$fila['via'];
		$_SESSION["indicaciones_terapeuticas"]=$fila['inicaciones terapeuticas'];
		$_SESSION["contraindicaciones"]=$fila['contraindicaciones'];
  {
		header("Location: nuevo.php");
		
  
		}elseif header("Location: clasificacion.php");{ 
 
 
		 
         
  } 
               

?>

   
